alpha = float(raw_input("alpha = "))
beta = float(raw_input("beta = "))
epsilon = 10**(-10.0)

def f(y,x,phi):
    a = y[1]
    if x == 0.0 and y[0] == 0.0:
        b = 0.0
    elif x != 0.0 and y[0] == 0.0:
        b = ((1 - alpha)/x)*y[1]
    elif x == 0.0 and y[0] != 0.0:
        b = ((alpha**2)*(phi**2)*(1+beta)*y[0])/(beta + y[0])
    elif x != 0.0 and y[0] != 0.0:
        b =  ((1 - alpha)/x)*y[1] + ((alpha**2)*(phi**2)*(1+beta)*y[0])/(beta + y[0])
    c = [a,b]
    return(c)

def operate(a,b,k):
    c = []
    for i in range(len(a)):
        c.append(a[i] + k*b[i])
    return(c)

def r_k4(y2,a,h,phi):
    sol =  [y2,0.0]
    o = []
    x = a
    while x <= 1.0:
        o.append(sol)
        k1 = f(sol,x,phi)
        k2 = f(operate(sol,k1,h/2.0),(x + h/2.0),phi)
        k3 = f(operate(sol,k2,h/2.0),(x + h/2.0),phi)
        k4 = f(operate(sol,k3,h),(x + h),phi)
        sol = operate(operate([0.0,0.0],operate(operate(operate(k1,k2,2.0),k3,2.0),k4,1.0),h/6.0) ,sol ,1.0)
        x = x + h
    return(o)

def error(y2,a,h,phi):
    o = r_k4(y2,a,h,phi)
    l = o[(len(o)-1)][0]
    b = abs(1.0 - l)
    return(b)

def shoot(y2,a,h,phi):
    while  (abs(error(y2,a,h,phi))) > 10**(-10) :
        final = y2 - (error(y2,a,h,phi)/((error(y2+epsilon,a,h,phi) - error(y2-epsilon,a,h,phi))/(2.0*epsilon)))
        y2 = final
    return(r_k4(final,a,h,phi))

def fuc(y2,a,h,phi):
    p = shoot(y2,a,h,phi)
    b = p[0][0]
    return(b)

def subs(y2,h,phi):
    al=0.0
    ar=1.0
    a = 0.0
    while (ar - al) > 10**(-10):
        if fuc (y2,a,h,phi) >= 0.0:
            ar = a
        elif fuc (y2,a,h,phi) < 0.0:
            al = a
        a = (al + ar)/2.0
    #return (shoot(y2,a,h,phi))
    return([shoot(y2,a,h,phi),a])

def thielle(y2,h):
    phi_l =  0
    phi_r = 100
    phi = 2

    while (phi_r - phi_l) > 10**(-10):
        if fuc(y2,0.0,h,phi) >= 0.0:
            phi_l = phi
        elif fuc(y2,0.0,h,phi) < 0.0:
            phi_r = phi
        phi = (phi_r + phi_l)/2.0
        if phi >= 99.999999:
            break
    return(phi)

def n(y2,h,phi):
    l = subs(y2,h,phi)
    o = l[0][len(l[0])-1][1]
    k = alpha*phi*phi
    b = (o/k)
    return (b)

def error_n(y2,a,h,phi,na):
    l = n(y2,a,h,phi)
    e = abs(na - l)
    return(a)

def error_phi(y2,h,phi,phia):
    o = thielle(y2,h,phi)
    e = abs(phia - o)
    return(e)

b = open('output.txt','w')
x = 0.0
a = subs(0.0,0.001,1.0)
if (a[1]) == 0.0:
    for i in range(len(a[0])):
        b.write(str(a[0][i][0]))
        b.write("\n")
else:
    while x < a[1]:
        b.write(str(a[0][0][0]))
        b.write("\n")
        x = x + 0.001
    if x >= (a[1]):
        for i in range(len(a[0])):
            b.write(str(a[0][i][0]))
            b.write("\n")
