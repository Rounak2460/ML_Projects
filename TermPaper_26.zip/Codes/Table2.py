import re
def f(A,B,Z,S,phi,a,i):
    q = 0
    S.append(1.0)
    for j in range(len(A)):
        q = q + ((B[i][j]*S[j])/((1-a)**2.0)) + (((alpha - 1.0)*(A[i][j]*S[j]))/((Z[i]*(1-a) + a)*(1-a)))
    if beta != 0.0:
        z = q  - ((alpha**2.0)*(phi**2.0)*(1+beta)*S[i])/(beta + S[i])
    elif beta == 0.0:
        z = q  - ((alpha**2.0)*(phi**2.0))
    del S[len(S)-1]
    return(z)

def g(A,S):
    b = 0
    S.append(1.0)
    for i in range(len(A)):
        b = b + A[0][i]*S[i]
    del S[len(S)-1]
    return(b)

def der(A,B,Z,S,phi,a,i,j):
    epsilon = 10**(-6)
    S[j] = S[j] + epsilon
    q = f(A,B,Z,S,phi,a,i)
    S[j] = S[j] - (epsilon)
    r = f(A,B,Z,S,phi,a,i)
    t = (q - r)/(epsilon)
    return (t)

def der1(A,S,j):
    epsilon = 10**(-6)
    S[j] = S[j] + epsilon
    q = g(A,S)
    S[j] = S[j] - (epsilon)
    r = g(A,S)
    t = (q - r)/(epsilon)
    return (t)

def jacobi(A,B,Z,S,phi,a):
    b = []
    c = []
    for i in range(len(A)-1):
        b.append(der1(A,S,i))
    c.append(b)
    for i in range(1,(len(A)-1)):
        d = []
        for j in range((len(A)-1)):
            d.append(der(A,B,Z,S,phi,a,i,j))
        c.append(d)
    return(c)

def norm (final,initial):
    sum = 0.0
    for i in range(len(final)):
        sum = sum + (final[i] - initial[i])**2.0
    return(sum**(0.5))

def swap_row(m,j):
    maxi = m[j][j]
    k = j
    for i in range(j,len(m)):
        if abs(maxi) < abs(m[i][j]):
            maxi = m[i][j]
            k = i
    c = m[k]
    m[k] = m[j]
    m [j] = c
    return m

def row_operation(m,i,j,c):
    for x in range(len(m[i])):
        m[j][x] = m[j][x] + (c * m[i][x])
    return m


def gauss (m):
    for i in range(0,len(m)):
        swap_row(m,i)
        for k in range((i+1),len(m)):
            if m[i][i] == 0:
                break
            c = (-1.0)*((m[k][i])/(m[i][i]))
            row_operation(m,i,k,c)
    return m

def check_row(m,k):
    a = True
    for j in (m[k]):
        if j != 0.0:
            a = False
            break
    return a

def check_row2(m,sol,k):
    a = False
    sum = 0
    for i in range(len(m)):
        sum = sum + m[k][i]*sol[i]
    if sum == m[k][len(m)]:
        a = True
    return a
def back_sub(l):
    b = []
    m = gauss(l)
    sol = [1]*(len(m))
    for k in xrange((len(m)-1),-1,-1):
        sum = 0
        for j in range(len(m[0])-1):
            if j == k :
                continue
            sum = sum + (m[k][j]*sol[j])
        if m[k][k] == 0 and check_row(m,k) == True:
            b = [-1.0]
            break
        elif m[k][k] == 0 and check_row(m,k) != True and check_row2(m,sol,k) == True:
            b = [-1.0]
            break
        elif m[k][k] == 0 and check_row(m,k) != True and check_row2(m,sol,k) == False:
            b = [0.0]
            break
        sol[k] = ((m[k][(len(m))] - sum))/m[k][k]
        b = sol
    return b


def augmnt(a,b):
    for i in range(len(a)):
        (a[i]).append(b[i])
    return a

def n_r(A,B,Z,phi,a):
    initial = [0.0 for i in range(len(A)-1)]
    final = [1.0 for i in range(len(A)-1)]
    while norm(final,initial) > 10**(-6):
        initial = [i for i in final]
        m = jacobi(A,B,Z,initial,phi,a)
        sol = [(-1.0)*g(A,initial)]
        for i in range(1,(len(A)-1)):
            sol.append((-1.0)*f(A,B,Z,initial,phi,a,i))
        k = augmnt(m,sol)
        del_c = back_sub(k)
        for i in range(len(A)-1):
            final[i] = initial[i] + del_c[i]
    return (final)

def subs(A,B,Z,phi):
    al=0.0
    ar=1.0
    a = 0.0
    while (ar - al) > 10**(-10):
        if (n_r(A,B,Z,phi,a))[0] >= 0.0:
            ar = a
        elif (n_r(A,B,Z,phi,a))[0] < 0.0:
            al = a
        a = (al + ar)/2.0
    #return (shoot(y2,a,h,phi))
    return([n_r(A,B,Z,phi,a),a])

def thielle(A,B,Z):
    phi_l =  0
    phi_r = 100
    phi = 2
    while (phi_r - phi_l) > 10**(-10):
        if (n_r(A,B,Z,phi,0.0))[0] >= 0.0:
            phi_l = phi
        elif (n_r(A,B,Z,phi,0.0))[0] < 0.0:
            phi_r = phi
        phi = (phi_r + phi_l)/2.0
        if phi >= 99.999999:
            break
    return(phi)

def n1(A,B,Z,phi):
    b = subs(A,B,Z,phi)
    s = b[0]
    a = b[1]
    s.append(1.0)
    c = 0.0
    for i in range(len(A)):
        c = c + (A[len(A)-1][i])*s[i]
    k = alpha*phi*phi
    z = (c)/((1-a)*k)
    return(z)

def convrt(s):
        b = []
        c = re.sub(' +',' ',s)
        a = c.split()
        for i in a:
            b.append(float(i))
        return b

A = [[-7.0,8.196,-2.196,1.0],[-2.732,1.732,1.732,-0.732],[0.7321,-1.732,-1.732,2.732],[-1.0,2.196,-8.196,7.0]]
B = [[24.0,-37.18,25.18,-12.0],[16.39,-24.0,12.0,-4.392],[-4.392,12.0,-24.0,16.39],[-12.0,25.12,-37.18,24.0]]
Z = [0.0,0.21132,0.78868,1.0]

m = open('input.txt','r')
n = open('output.txt' , 'w')
n.write("phi-numerical  a(Dead-core)  IEF(numerical)")
n.write("\n")
for i in range(24):
    x = convrt((m.readline()))
    alpha = x[1]
    phi = x[2]
    if x[0] == 0.0:
        beta = 0.0
        n.write(str(round(thielle(A,B,Z),4)) + "           " + str(round(subs(A,B,Z,phi)[1] , 4)) + "         " + str(round(n1(A,B,Z,phi),4)))
        n.write("\n")
        
    elif x[0] == 1.0:
        beta = 100000000
        n.write("-------" + "           " + str(round(subs(A,B,Z,phi)[1] , 4)) + "         " + str(round(n1(A,B,Z,phi),4)))
        n.write("\n")
