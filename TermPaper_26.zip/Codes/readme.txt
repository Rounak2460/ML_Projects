Table1.py : when run and prints numerical values for table 1 in output.txt
Table2.py : when run and prints numerical values for table 1 in output.txt
Substrate.py: when run demands value of alpha and beta and then prints corresponding substrate profile in output for h =0.001
N_vs_phi.py:when run demands value of alpha and beta and then prints corresponding data of IEF vs phi

Do not change input.